﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using test01.Model;
using test01.View;
using test01.Controller;

namespace test01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        HandView hand;
        GameManager gm;

        private void Form1_Load(object sender, EventArgs e)
        {
            ResourceManager.initialize();
            hand = new HandView();
            gm = new GameManager();
            hand.Initialize(gm);
            gm.Initialize();
            this.Click += Background_Click;

            this.Controls.Add(hand);
            hand.Location = new Point(50, 200);
        }
        private void Background_Click(object sender, EventArgs e)
        {
            //當點擊 Form1 空白處時，取消選取所有元件
            hand.Unselect();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using test01.Model;

namespace test01.View
{
    public static class ResourceManager
    {
        private static Dictionary<(Card.Suit Suit, Card.Rank Rank), Image> cardFaceImages =
            new Dictionary<(Card.Suit, Card.Rank), Image>();
        private static Image cardBackImage;

        public static void initialize()
        {
            string baseDir = Path.Combine(Application.StartupPath, "Assets/img");

            //卡背
            string backPath = Path.Combine(baseDir, "card_back.png");
            if (File.Exists(backPath))
            {
                cardBackImage = Image.FromFile(backPath);
            }

            //卡面
            foreach (Card.Suit suit in Enum.GetValues(typeof(Card.Suit)))
            {
                foreach (Card.Rank rank in Enum.GetValues(typeof(Card.Rank)))
                {
                    string key = $"{suit}_{rank}";
                    string fullPath = Path.Combine(baseDir, $"{key}.png");
                    if (File.Exists(fullPath))
                    {
                        cardFaceImages[(suit, rank)] = Image.FromFile(fullPath);
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine(fullPath + " loaded error");
                    }
                }
            }
        }
        public static Image getCardFaceImage(Card.Suit suit, Card.Rank rank)
        {
            if (cardFaceImages.TryGetValue((suit, rank), out Image img))
            {
                return img;
            }

            return null;
        }
        public static Image getCardBackImage()
        {
            return cardBackImage;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using test01.Controller;
using test01.Model;

namespace test01.View
{
    public partial class HandView : UserControl
    {
        private GameManager _gameManager;

        public HandView()
        {
            InitializeComponent();
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        }
        public void Initialize(GameManager gameManager)
        {
            _gameManager = gameManager;
            _gameManager.OnPlayerHandChanged += HandleHandChanged;
        }
        public void Draw(IEnumerable<Card> hand)
        {
            this.Controls.Clear();

            int currentX = 0;
            int y = 30; //預留30px頂部浮動空間供選取時上浮
            int spacing = 30;

            foreach (var card in hand)
            {
                CardView cardView = new CardView(card);
                cardView.Location = new Point(currentX, y);
                cardView.CardPlayed += OnCardPlayed; //訂閱該牌被打出的事件

                this.Controls.Add(cardView);
                cardView.BringToFront();
                currentX += spacing;
            }
        }
        public void Unselect()
        {
            foreach (Control control in this.Controls)
            {
                if (control is CardView cardView)
                {
                    cardView.Unselect();
                }
            }
        }
        private void OnCardPlayed(object sender, EventArgs e)
        {
            CardView playedCard = sender as CardView;
            if (playedCard == null) return;

            this.Controls.Remove(playedCard);
            playedCard.Dispose();

            // 3. 【重要】你還需要呼叫 Controller (GameManager) 將這張牌從 Model 的 Player 手牌名單中移除
            // GameManager.PlayCard(playedCard.BoundCard);

            // 4. 重新計算剩下卡牌的座標與重繪
            // 這邊可以再次呼叫你的 draw 方法，或是寫一個重新排列現有 Controls 座標的方法
        }
        private void HandleHandChanged(object sender, EventArgs e)
        {
            //確保主執行緒觸發時才作用
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => HandleHandChanged(sender, e)));
                return;
            }

            var currentHand = _gameManager.GetCurrentPlayerHand();
            Draw(currentHand);
        }
    }
}
